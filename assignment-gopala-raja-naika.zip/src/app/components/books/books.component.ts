import { Component, OnInit } from '@angular/core';
import { BooksService } from 'src/app/services/books.service';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.scss']
})
export class BooksComponent implements OnInit {

  books:any = []

  constructor(private bookService: BooksService) { }

  ngOnInit() {
    this.getBooksData();
  }

  getBooksData(){
    this.bookService.getBooksData.subscribe((data:any) => {
      this.books = data;
    })
  }

  trackByMethod(index:number, el:any): number {
    return el.bookId;
  }

}
