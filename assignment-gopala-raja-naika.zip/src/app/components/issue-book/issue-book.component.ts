import { Component, OnInit, ViewChild } from '@angular/core';
import { BooksService } from 'src/app/services/books.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-issue-book',
  templateUrl: './issue-book.component.html',
  styleUrls: ['./issue-book.component.scss']
})
export class IssueBookComponent implements OnInit {
  books: any = [];
  myForm: NgForm;
  formData: any = {};
  @ViewChild("myNgForm") myNgForm: NgForm;

  constructor(private bookService: BooksService) { }

  ngOnInit() {
    this.getBooksData();
  }

  getBooksData() {
    this.bookService.getBooksData.subscribe((data: any) => {
      this.books = data;
    })
  }

  issueBook() {
    if (this.myNgForm.valid) {
      let index = this.books.findIndex(x => x.bookId == this.formData.bookId);
      if (index !== -1) {
        this.books[index].quantity = parseInt(this.books[index].quantity) - 1;
        this.bookService.setBooksData(this.books);
        console.log("Success");
        console.log(this.myNgForm.value);
        alert("Submitted successfully")
      }
    }
  }

  setReturnDate() {

    const date = new Date()
    const nextDay = new Date(date)
    nextDay.setDate(nextDay.getDate() + this.formData.duration);


    let day = ("0" + nextDay.getDate()).slice(-2);
    let month = ("0" + (nextDay.getMonth() + 1)).slice(-2);
    let year = nextDay.getFullYear();

    let fullDate = day + '-' + month + '-' + year;
    this.formData.returnDate = fullDate;
  }

}
