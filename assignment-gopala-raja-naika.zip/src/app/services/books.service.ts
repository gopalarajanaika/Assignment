import { Injectable } from '@angular/core';
import { Observable, Subject, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BooksService {

  books = [
    { "bookId": 1001, "title": "Agile Web Development", "author": "Sam Ruby", "category": "Web development", "pages": 450, "description": "", "quantity": 10 },
    { "bookId": 1002, "title": "Javascript crash course", "author": "John Robert", "category": "Web development", "pages": 850, "description": "", "quantity": 5 },
    { "bookId": 1003, "title": "Angular crash course", "author": "Subhash Guru", "category": "Web development", "pages": 485, "description": "", "quantity": 20 },
    { "bookId": 1003, "title": "Java crash course", "author": "Subhash Guru", "category": "Desktop Application development", "pages": 485, "description": "", "quantity": 15 }
  ]
  getBooksData = new BehaviorSubject(this.books);

  constructor() { }

  setBooksData(books) {
    this.getBooksData.next(books)
  }
}


