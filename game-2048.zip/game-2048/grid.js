function blankGrid() {
  return [
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0]
  ];
}

function compare(a, b) {
  for (let i = 0; i < grid.length; i++) {
    for (let j = 0; j < grid.length; j++) {
      if (a[i][j] !== b[i][j]) {
        return true;
      }
    }
  }
  return false;
}

function copyGrid(grid) {
  let extra = blankGrid();
  for (let i = 0; i < grid.length; i++) {
    for (let j = 0; j < grid.length; j++) {
      extra[i][j] = grid[i][j];
    }
  }
  return extra;
}

function flipGrid(grid) {
  for (let i = 0; i < grid.length; i++) {
    grid[i].reverse();
  }
  return grid;
}

function transposeGrid(grid) {
  let newGrid = blankGrid();
  for (let i = 0; i < grid.length; i++) {
    for (let j = 0; j < grid.length; j++) {
      newGrid[i][j] = grid[j][i];
    }
  }
  return newGrid;
}

function addNumber() {
  let options = [];
  for (let i = 0; i < grid.length; i++) {
    for (let j = 0; j < grid.length; j++) {
      if (grid[i][j] === 0) {
        options.push({
          x: i,
          y: j
        });
      }
    }
  }
  if (options.length > 0) {
    let spot = options[Math.floor(Math.random() * options.length)];
    let r = Math.random(1);
    grid[spot.x][spot.y] = r > 0.1 ? 2 : 4;
  }
}
