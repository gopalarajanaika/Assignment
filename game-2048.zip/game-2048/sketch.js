let table = document.querySelector("table");
let scoreEl = document.querySelector("#score");
let grid;
let score = 0;

setup();

window.addEventListener("keydown", function (e) {
  keyPressed(e.code);
})

function setup() {
  grid = blankGrid();
  addNumber();
  addNumber();
  updateCanvas();
}

// One "move"
function keyPressed(keyCode) {
  let flipped = false;
  let rotated = false;
  let played = true;
  switch (keyCode) {
    case "ArrowDown":
      grid = transposeGrid(grid);
      rotated = true;
      break;
    case "ArrowUp":
      grid = transposeGrid(grid);
      grid = flipGrid(grid);
      rotated = true;
      flipped = true;
      break;
    case "ArrowRight":
      // no action
      break;
    case "ArrowLeft":
      grid = flipGrid(grid);
      flipped = true;
      break;
    default:
      played = false;
  }

  if (played) {
    let past = copyGrid(grid);
    for (let i = 0; i < grid.length; i++) {
      grid[i] = operate(grid[i]);
    }
    let changed = compare(past, grid);
    if (flipped) {
      grid = flipGrid(grid);
    }
    if (rotated) {
      grid = transposeGrid(grid);
    }
    if (changed) {
      addNumber();
    }
    updateCanvas();

    let gameover = isGameOver();
    if (gameover) {
      console.log('GAME OVER');
    }

    let gamewon = isGameWon();
    if (gamewon) {
      console.log('GAME WON');
    }
  }
}

function updateCanvas() {
  drawGrid();
  scoreEl.innerHTML = score;
}

function drawGrid() {

  table.innerHTML = "";
  for (let i = 0; i < grid.length; i++) {
    let tr = document.createElement("tr");
    for (let j = 0; j < grid.length; j++) {

      let td = document.createElement("td");
      let textNode = document.createTextNode(grid[i][j] ? grid[i][j] : '');
      td.appendChild(textNode);
      tr.appendChild(td);
    }

    table.appendChild(tr);
  }
}
