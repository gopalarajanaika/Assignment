import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BooksService } from 'src/app/services/books.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-issue-return-book',
  templateUrl: './issue-return-book.component.html',
  styleUrls: ['./issue-return-book.component.scss']
})
export class IssueReturnBookComponent implements OnInit {
  books: any = [];
  myForm: NgForm;
  formData: any = {};
  @ViewChild("myNgForm") myNgForm: NgForm;
  pageUrl: string;
  routeUrl: string;

  constructor(private bookService: BooksService, private router:Router) { }

  ngOnInit() {
    this.pageUrl = this.router.url;
    this.pageUrl = this.pageUrl.split("/")[this.pageUrl.split("/").length - 1];
    this.getBooksData();
  }

  getBooksData() {
    this.bookService.getBooksData.subscribe((data: any) => {
      this.books = data;
    })
  }

  onSubmit() {
    if (this.myNgForm.valid) {
      let index = this.books.findIndex(x => x.bookId == this.formData.bookId);
      if (index !== -1) {
        
        if( this.pageUrl == 'issue-book')
        this.books[index].quantity = parseInt(this.books[index].quantity) - 1;
        else
        this.books[index].quantity = parseInt(this.books[index].quantity) + 1;

        this.bookService.setBooksData(this.books);
        console.log("Success");
        // console.log(this.myNgForm.value);
        alert("Submitted successfully")
        this.myNgForm.resetForm();
      }
    }
  }

  setReturnDate() {

    const date = new Date()
    const nextDay = new Date(date)
    nextDay.setDate(nextDay.getDate() + this.formData.duration);


    let day = ("0" + nextDay.getDate()).slice(-2);
    let month = ("0" + (nextDay.getMonth() + 1)).slice(-2);
    let year = nextDay.getFullYear();

    let fullDate = day + '-' + month + '-' + year;
    this.formData.returnDate = fullDate;
  }

  
  returnBook() {
    if (this.myNgForm.valid) {
      let index = this.books.findIndex(x => x.bookId == this.formData.bookId);
      if (index !== -1) {
        this.books[index].quantity = parseInt(this.books[index].quantity) + 1;
        this.bookService.setBooksData(this.books);
        console.log("Success");
        console.log(this.myNgForm.value);
        alert("Submitted successfully")
      }
    }
  }


}