import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  showNavbar: boolean;

  constructor(private sharedService: SharedService) { }

  ngOnInit() {
    this.sharedService.getToggleNavbar.subscribe((res:boolean) => {
      console.log(res);
      this.showNavbar = res;
    })
  }

  setNavbarToogleValue(){
    this.sharedService.setNavbarToogleValue(false);
  }

}
