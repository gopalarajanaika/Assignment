import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  showNavbar:boolean = false;

  getToggleNavbar = new BehaviorSubject(this.showNavbar);

  constructor() { }

  setNavbarToogleValue(value) {
    this.getToggleNavbar.next(value)
  }

}
